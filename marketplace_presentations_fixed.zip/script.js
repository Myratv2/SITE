// Firebase auth + логика сайта + storage + VIP

import { initializeApp } from "https://www.gstatic.com/firebasejs/10.11.1/firebase-app.js";
import { getAuth, signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.11.1/firebase-auth.js";
import { getStorage, ref, uploadBytes, listAll, getDownloadURL } from "https://www.gstatic.com/firebasejs/10.11.1/firebase-storage.js";
import { getFirestore, doc, getDoc } from "https://www.gstatic.com/firebasejs/10.11.1/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "ВСТАВЬ_СЮДА",
  authDomain: "ВСТАВЬ_СЮДА",
  projectId: "ВСТАВЬ_СЮДА",
  storageBucket: "ВСТАВЬ_СЮДА",
  messagingSenderId: "ВСТАВЬ_СЮДА",
  appId: "ВСТАВЬ_СЮДА"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const storage = getStorage(app);
const db = getFirestore(app);

function toggleTheme() {
  document.body.classList.toggle('dark');
  const themeBtn = document.getElementById('themeToggle');
  themeBtn.textContent = document.body.classList.contains('dark') ? 'На яркий' : 'На тёмный';
}

function toggleMenu() {
  document.getElementById('menuItems').classList.toggle('show');
}

window.login = function(event) {
  event.preventDefault();
  const email = document.getElementById('username').value;
  const password = document.getElementById('password').value;

  signInWithEmailAndPassword(auth, email, password)
    .then((userCredential) => {
      const user = userCredential.user;
      showProfile(user);
    })
    .catch((error) => {
      alert("Ошибка входа: " + error.message);
    });
};

window.register = function(event) {
  event.preventDefault();
  const email = document.getElementById('username').value;
  const password = document.getElementById('password').value;

  createUserWithEmailAndPassword(auth, email, password)
    .then(() => {
      alert("Пользователь успешно зарегистрирован! Теперь войдите.");
    })
    .catch((error) => {
      alert("Ошибка регистрации: " + error.message);
    });
};

window.logout = function() {
  signOut(auth).then(() => {
    document.getElementById('auth').style.display = 'block';
    document.getElementById('profile').style.display = 'none';
  });
};

onAuthStateChanged(auth, (user) => {
  if (user) {
    showProfile(user);
  } else {
    document.getElementById('auth').style.display = 'block';
    document.getElementById('profile').style.display = 'none';
  }
});

function showProfile(user) {
  document.getElementById('auth').style.display = 'none';
  document.getElementById('profile').style.display = 'block';
  document.getElementById('welcomeText').textContent = `Добро пожаловать, ${user.email}!`;
  loadPresentations(user);
  checkVip(user);
}

async function checkVip(user) {
  const vipStatus = document.getElementById('vipStatus');
  const vipPayment = document.getElementById('vipPayment');
  const premiumSection = document.getElementById('premiumSection');

  const docRef = doc(db, "users", user.uid);
  const docSnap = await getDoc(docRef);

  if (docSnap.exists() && docSnap.data().isVIP === true) {
    vipStatus.textContent = "У вас VIP доступ! Спасибо за поддержку ✨";
    vipPayment.style.display = "none";
    premiumSection.style.display = "block";
    loadPremiumPresentations();
  } else {
    vipStatus.textContent = "У вас нет VIP доступа.";
    vipPayment.style.display = "block";
    premiumSection.style.display = "none";
  }
}

async function loadPremiumPresentations() {
  const premiumList = document.getElementById('premiumList');
  premiumList.innerHTML = "Загрузка...";
  const listRef = ref(storage, 'premium_presentations/');
  try {
    const res = await listAll(listRef);
    premiumList.innerHTML = "";
    for (const itemRef of res.items) {
      const url = await getDownloadURL(itemRef);
      const li = document.createElement('li');
      li.innerHTML = `<a href="${url}" target="_blank">${itemRef.name}</a>`;
      premiumList.appendChild(li);
    }
    if (res.items.length === 0) {
      premiumList.innerHTML = "Премиум-презентаций пока нет.";
    }
  } catch (error) {
    premiumList.innerHTML = "Ошибка загрузки премиум-презентаций.";
  }
}

window.uploadPresentation = function () {
  const fileInput = document.getElementById('presentationFile');
  const file = fileInput.files[0];
  if (!file) {
    alert("Выберите файл.");
    return;
  }

  const user = auth.currentUser;
  const fileRef = ref(storage, `presentations/${user.uid}/${file.name}`);

  uploadBytes(fileRef, file)
    .then(() => {
      alert("Файл успешно загружен!");
      loadPresentations(user);
    })
    .catch((error) => {
      alert("Ошибка загрузки: " + error.message);
    });
};

function loadPresentations(user) {
  const listRef = ref(storage, `presentations/${user.uid}/`);
  const listElement = document.getElementById('presentationList');
  listElement.innerHTML = "Загрузка...";

  listAll(listRef)
    .then((res) => {
      listElement.innerHTML = "";
      res.items.forEach((itemRef) => {
        getDownloadURL(itemRef).then((url) => {
          const li = document.createElement('li');
          li.innerHTML = `<a href="${url}" target="_blank">${itemRef.name}</a>`;
          listElement.appendChild(li);
        });
      });
      if (res.items.length === 0) {
        listElement.innerHTML = "Нет загруженных презентаций.";
      }
    })
    .catch(() => {
      listElement.innerHTML = "Ошибка загрузки презентаций.";
    });
}
